qwerty
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table>
	<tr>
		<th>Name</th>
		<th>Gender</th>
	</tr>
	<!-- @foreach($user as $val)
	<tr>
		<td>{{ $val->name }}</td>
		<td>{{ $val->gender }}</td>
	</tr>
	@endforeach -->
</table>
</body>
</html>