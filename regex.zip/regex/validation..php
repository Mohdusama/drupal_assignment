 
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<style>
input[type=text],input[type=email],input[type=number]{
  width: 50%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

button[type=submit] {
  width: 10%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button[type=submit]:hover {
  background-color: #45a049;
}
</style>
</head>
<body>
  <form>
    <label for="fname">First Name</label><br>
    <input type="text" id="fname" name="firstname" placeholder="Your name.." oninput="fname()">
    <span class="fnameerror"></span><br>
    <label for="lname">Last Name</label><br>
    <input type="text" id="lname" name="lastname" placeholder="Your last name..">
    <span class="lnameerror"></span><br>
    <label for="contact">Contact</label><br>
    <input type="number" id="contact" name="contact" placeholder="Your contact..">
    <span class="contacterror"></span><br>
    <label for="email">Email</label><br>
    <input type="email" id="email" name="email" placeholder="Your email..">
    <span class="emailerror"></span><br>
    <button type="submit">Submit</button>
  </form>

  <p id="error"></p>
<script type="text/javascript">
try{
	$(document).ready(function(){
		$flag=0;
		$('#fname').on('keypress keydown keyup',function(){
			if($(this).val().match(/^(A|P|Q|Z)[a-zA-Z]+(Biya|We|Jzz)$/)){
				$(".fnameerror").html("Correct");
				$(".fnameerror").css("color", "green");
				$("#fname").css("background-color", "green");
				$flag=1;
			}else{
				$(".fnameerror").html("Username should only start with letter A,P,Q,Z and end with Biya,We,Jzz");
				// $(this).val('');
				$(".fnameerror").css("color", "red");
				$("#fname").css("background-color", "red");
				$flag=0;
			}
		});
		$('#lname').on('keypress keydown keyup',function(){
			if($(this).val().match(/^(Bhfy|W124|Jv\.\!)[a-zA-Z]+(A|P|Q|Z)$/)){
				$(".lnameerror").html("Correct");
				$(".lnameerror").css("color", "green");
				$("#lname").css("background-color", "green");
				$flag=1;
			}else{
				$(".lnameerror").html("User the last name should start with Bhfy, W124, Jv.! and end with A, P,Q,Z");
				// $(this).val('');
				$(".lnameerror").css("color", "red");
				$("#lname").css("background-color", "red");
				$flag=0;
			}
		});
		$('#contact').on('keypress keydown keyup',function(){
			if($(this).val().match(/^[9678]{1}[0-9]{5,8}(7|3646|976)$/)){
				$(".contacterror").html("Correct");
				$(".contacterror").css("color", "green");
				$("#contact").css("background-color", "green");
				$flag=1;
			}else{
				$(".contacterror").html("Contact no. should start with 9,6,7,8 and end with 7,3646,976");
				// $(this).val('');
				$(".contacterror").css("color", "red");
				$("#contact").css("background-color", "red");
				$flag=0;
			}
		});
		$('#email').on('keypress keydown keyup',function(){
			if($(this).val().match(/^[a-zA-Z0-9_.]+@[a-zA-Z]+\.[a-zA-Z]{2,3}$/)){
				$(".emailerror").html("Correct");
				$(".emailerror").css("color", "green");
				$("#email").css("background-color", "green");
				$flag=1;
			}else{
				$(".emailerror").html("InCorrect Email Format");
				// $(this).val('')
				$(".emailerror").css("color", "red");
				$("#email").css("background-color", "red");
				$flag=0;
			}
		});
		$("button").click(function(){
    		if($flag==1 && $('#fname').val()!='' && $('#lname').val()!='' && $('#contact').val()!='' && $('#email').val()!='')
    		{
    			alert('Welcome!!');
    		}
    		else{
    			alert('There must be an invalid info..');
    		}
  		});
	});
}
catch(err) {
	$("#error").html(err.message); 
} 
</script>
</body>
</html>
